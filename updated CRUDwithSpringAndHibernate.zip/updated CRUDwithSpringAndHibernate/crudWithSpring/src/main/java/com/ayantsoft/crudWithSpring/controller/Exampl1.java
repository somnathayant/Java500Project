package com.ayantsoft.crudWithSpring.controller;

public class Exampl1 {

}
