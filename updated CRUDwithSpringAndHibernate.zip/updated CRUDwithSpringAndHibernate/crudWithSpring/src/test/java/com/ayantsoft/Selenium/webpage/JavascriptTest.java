package com.ayantsoft.Selenium.webpage;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class JavascriptTest {

	@Test
	public void fun(){
		WebDriver driver = new FirefoxDriver();
		
		String baseUrl = "http://localhost:8081/crudWithSpring";	
	    driver.get(baseUrl);
	    
	    WebElement addEmp = driver.findElement(By.id("addEmp"));	
	    addEmp.click();
	    
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    
	    WebElement empName = driver.findElement(By.id("name"));					 
	    WebElement empPass = driver.findElement(By.id("pass"));					 
	    WebElement empEmail = driver.findElement(By.id("email"));					 
	    WebElement empCity = driver.findElement(By.id("city"));					 
	     
	     
	    empEmail.sendKeys("selenium@gmail.com");;
	    empName.sendKeys();
	    empPass.sendKeys("selenium@123");
	    empCity.sendKeys("selenium City");
	    
	    JavascriptExecutor js =(JavascriptExecutor)driver;
        js.executeScript("submission();");
 
        
	}



}
