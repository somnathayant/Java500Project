package com.ayantsoft.selenium.cases;


//usage of locators
public class Selenium1 {
			
	
	
	
				
}
