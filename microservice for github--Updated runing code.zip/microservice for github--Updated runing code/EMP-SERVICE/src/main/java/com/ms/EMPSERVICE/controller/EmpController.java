package com.ms.EMPSERVICE.controller;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ms.EMPSERVICE.AcctProxy;



@RequestMapping("/EMP-SERVICE")
@RestController
public class EmpController {

	
	@Autowired
	private AcctProxy acctProxy;
	
	@GetMapping("/")
	public String ping() {
		return "ok";
	}
	
	@GetMapping("/getAllFromAcct")
	public ResponseEntity<Data>getAllFromAcct(){
		
		Data ob=new Data();
		ob=acctProxy.getAllFromAcct();
		return new ResponseEntity<Data>(ob,HttpStatus.OK);
		
	}
	@PostMapping("/setAllFromAcct")
	public ResponseEntity<Data>setAllToAcct(@ RequestBody Data ob){
		
		
		ob.setDot(new Date());
		
		ob=acctProxy.setAllToAcct(ob);
		return new ResponseEntity<Data>(ob,HttpStatus.OK);
		
	}
	@GetMapping("/getDummyFromAcct")
	public ResponseEntity<Data>getDummyFromAcct(){
		
		Data ob=new Data();
		ob=acctProxy.getDummyFromAcct();
		return new ResponseEntity<Data>(ob,HttpStatus.OK);
		
	}
}
