package com.boot1.boot1;

import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;


//@FeignClient(name="boot")

@FeignClient(name="zull")
@RibbonClient("boot")
public interface FeignClientProxy {
	@GetMapping(value="/boot/students")
	public Student students();
	
}
