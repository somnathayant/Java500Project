package com.ayantsoft.serv;

public class Student {

	private String name;
	private Integer st_id;
	private Integer roll;
	
}
