package com.ayantsoft.eureka.eureka;

import org.springframework.web.bind.annotation.RestController;

import io.micrometer.core.instrument.MeterRegistry;
import jakarta.annotation.PostConstruct;

@RestController
public class PingController {

	
	private  MeterRegistry meterRegistry;

    public PingController(MeterRegistry meterRegistry) {
        this.meterRegistry = meterRegistry;
    }

    @PostConstruct
    public void init() {
        // Example: Create and increment a counter metric
        meterRegistry.counter("myapp_custom_metric_total", "type", "example").increment();
    }
	
}
