package com.ms.EMPSERVICE;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.ms.EMPSERVICE.controller.Data;

@FeignClient(
	    name = "GATEWAY-SERVER",
	    configuration = FeignJwtForwardingInterceptor.class
	)
public interface AcctProxy {

	@GetMapping(value="/ACCT-SERVICE/getAdmin")
	public Data getAllFromAcct();
	
	@GetMapping(value="/ACCT-SERVICE/getDummy")
	public Data getDummyFromAcct();
	
	@PostMapping("/ACCT-SERVICE/setAll")
	public Data setAllToAcct(Data ob);
}
