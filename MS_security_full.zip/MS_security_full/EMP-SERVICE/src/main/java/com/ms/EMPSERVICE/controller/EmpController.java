package com.ms.EMPSERVICE.controller;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ms.EMPSERVICE.AcctProxy;

import feign.FeignException;



@RequestMapping("/EMP-SERVICE")
@RestController
public class EmpController {

	
	@Autowired
	private AcctProxy acctProxy;
	
	@GetMapping("/")
	public String ping() {
		return "ok";
	}
	
	@GetMapping("/getAllFromAcct")
	public ResponseEntity<?>getAllFromAcct(){
		
		try {
	        Data ob = acctProxy.getAllFromAcct(); // Feign call via Gateway
	        return new ResponseEntity<>(ob, HttpStatus.OK);
	    } catch (FeignException.Forbidden ex) {
	        // Handle 403 specifically
	        return new ResponseEntity<>("Access Denied: You are not authorized to access this resource.", HttpStatus.FORBIDDEN);
	    } catch (FeignException.Unauthorized ex) {
	        // Handle 401
	        return new ResponseEntity<>("Unauthorized: Please log in again.", HttpStatus.UNAUTHORIZED);
	    } catch (FeignException ex) {
	        // Handle other Feign-related errors (400, 500, etc.)
	        return new ResponseEntity<>("Downstream service error: " + ex.getMessage(), HttpStatus.valueOf(ex.status()));
	    } catch (Exception ex) {
	        // Fallback for unknown exceptions
	        return new ResponseEntity<>("An unexpected error occurred: " + ex.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	}
	@PostMapping("/setAllFromAcct")
	public ResponseEntity<Data>setAllToAcct(@ RequestBody Data ob){
		
		
		ob.setDot(new Date());
		
		ob=acctProxy.setAllToAcct(ob);
		return new ResponseEntity<Data>(ob,HttpStatus.OK);
		
	}
	@GetMapping("/getDummyFromAcct")
	public ResponseEntity<Data>getDummyFromAcct(){
		
		Data ob=new Data();
		ob=acctProxy.getDummyFromAcct();
		return new ResponseEntity<Data>(ob,HttpStatus.OK);
		
	}
}
