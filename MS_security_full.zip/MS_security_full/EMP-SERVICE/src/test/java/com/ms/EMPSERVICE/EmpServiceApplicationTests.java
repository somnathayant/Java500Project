package com.ms.EMPSERVICE;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmpServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
