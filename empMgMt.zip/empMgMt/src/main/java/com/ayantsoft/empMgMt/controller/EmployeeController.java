package com.ayantsoft.empMgMt.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


import com.ayantsoft.empMgMt.employeeserviceImpl.EmployeeServiceImpl;
import com.ayantsoft.empMgMt.hibernate.pojo.Address;
import com.ayantsoft.empMgMt.hibernate.pojo.Employee;
import com.ayantsoft.empMgMt.model.EmployeeDto;

@RestController
public class EmployeeController {

	
	@Autowired
	EmployeeServiceImpl employeeServiceImpl;
	
	@RequestMapping(value="/",method=RequestMethod.GET)
	public String welcome() {
		
		return "server is running";
	}
	
	@RequestMapping(value="/saveEmployee",method=RequestMethod.POST)
	public ResponseEntity<?>saveEmployee(@RequestBody EmployeeDto employeeDto) {
		
		Employee e=new Employee();
		Address a=new Address();
		boolean isEmpSaved=false;
		
		try {
		e.setName(employeeDto.getName());
		e.setSalary(employeeDto.getSalary());
		e.setEmpId(employeeDto.getEmpId());
		a.setAddressId(employeeDto.getAddressId());
		a.setCity(employeeDto.getCity());
		a.setState(employeeDto.getState());
		
		e.setAddress(a);
		
		isEmpSaved=employeeServiceImpl.saveEmployee(e);
		
		}catch(Exception ex) {
			return new ResponseEntity<String>("Employee Not saved",HttpStatus.EXPECTATION_FAILED);
		}
		if(isEmpSaved)
		return new ResponseEntity<String>("Employee saved",HttpStatus.CREATED);
		else {
			return new ResponseEntity<String>("Employee Not saved",HttpStatus.EXPECTATION_FAILED);
		}
	}
	
	@RequestMapping(value="/emps",method=RequestMethod.GET)
	public ResponseEntity<?> emps(){

		HttpStatus httpStatus = null;
		List<Employee>emps=null;
		List<EmployeeDto>empDtos=new ArrayList<EmployeeDto>();
		EmployeeServiceImpl employeeServiceImpl=new EmployeeServiceImpl();
		
		try {
			emps=employeeServiceImpl.emps();

			if(emps!=null) {
				httpStatus=HttpStatus.OK;
				for(Employee e:emps){
					EmployeeDto eDto=new EmployeeDto();
					System.out.println(e.getName());
					eDto.setEmpId(e.getEmpId());
					eDto.setAddressId(e.getAddress().getAddressId());
					eDto.setName(e.getName());
					eDto.setSalary(e.getSalary());
					
					eDto.setCity(e.getAddress().getCity());
					
					eDto.setState(e.getAddress().getState());
					
					
					empDtos.add(eDto);
				}
			}else if(emps.size()==0){
				httpStatus=HttpStatus.EXPECTATION_FAILED;
				return new ResponseEntity<String>("No Employee",httpStatus);
			}
		}catch(Exception ex) {

			httpStatus=HttpStatus.EXPECTATION_FAILED;
			return new ResponseEntity<String>("No Employee",httpStatus);

		}
		return new ResponseEntity<List<EmployeeDto>>(empDtos,httpStatus);
	}

	
	@RequestMapping(value="/getEmpById",method=RequestMethod.GET)
	public ResponseEntity<?> getEmpById(@RequestBody EmployeeDto employeeDto){

		HttpStatus httpStatus = null;
		Employee emp=new Employee();
		EmployeeDto eDto=new EmployeeDto();
		
		try {
			emp=employeeServiceImpl.getEmpById(employeeDto.getEmpId());

			if(emp!=null) {
				httpStatus=HttpStatus.OK;
					eDto.setName(emp.getName());
					eDto.setSalary(emp.getSalary());
					eDto.setCity(emp.getAddress().getCity());
					eDto.setState(emp.getAddress().getState());
					eDto.setEmpId(emp.getEmpId());
					eDto.setAddressId(emp.getAddress().getAddressId());
				
			}
		}catch(Exception ex) {

			httpStatus=HttpStatus.EXPECTATION_FAILED;
			return new ResponseEntity<String>("No Employee",httpStatus);

		}
		System.out.println(httpStatus);
		return new ResponseEntity<EmployeeDto>(eDto,httpStatus);
	}

	
	
}
