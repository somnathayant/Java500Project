package com.ayantsoft.empMgMt.employeedao;

import java.io.Serializable;
import java.util.List;


import com.ayantsoft.empMgMt.hibernate.pojo.Employee;

public interface EmployeeDao extends Serializable{

	public boolean saveEmployee(Employee emp);
	public List<Employee>emps();
	public Employee getEmpById(Integer EmpId);
}
