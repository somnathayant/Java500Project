package com.ayantsoft.empMgMt.employeedaoImpl;

import java.io.Serializable;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.ayantsoft.empMgMt.employeedao.EmployeeDao;
import com.ayantsoft.empMgMt.hibernate.pojo.Employee;
import com.ayantsoft.empMgMt.hibernateUtil.HbernateUtil;

@Repository
public class EmployeeDaoImpl implements Serializable,EmployeeDao{

	/**
	 * serialVersionUID = 6526356630273305607L;
	 */
	private static final long serialVersionUID = 6526356630273305607L;

	@Override
	public boolean saveEmployee(Employee emp) {
			Session session=null;
			boolean isEmpSaved=false;
			try {
				session=HbernateUtil.openSession();
				session.beginTransaction();
				if(emp.getEmpId()==null) {
				session.save(emp.getAddress());
				session.save(emp);
				}else {
					session.update(emp.getAddress());
					session.update(emp);
				}
			session.getTransaction().commit();
			isEmpSaved=true;
		}catch(Exception ex) {
			session.getTransaction().rollback();
			
		}
		return isEmpSaved;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Employee> emps() {
		
		List<Employee> employees=null;
		Session session=null;
		try{
			//inner join of criteria
			session=HbernateUtil.openSession();
			Criteria criteria = session.createCriteria(Employee.class, "EMP")
					.createAlias("EMP.address", "ADDRESS");
					
			employees =criteria.list();
			
			
			/*here both the approach is done above with criteria  and below with HQL
			 * only emp and address table is used one can add other tables as well
			 * 
			 * */
			
			/*session=HbernateUtil.openSession();
			
			String hql = "FROM Emp EMP "
					+ "JOIN FETCH  EMP.address ADD";
					
			Query query = session.createQuery(hql);
			
			employees = ((List<Emp>) query.list());
*/
		
		}catch(Exception e){
			employees=null;
			e.printStackTrace();
			}
		finally{
			session.close();
		}
		return employees;
		
	}

	@Override
	public Employee getEmpById(Integer EmpId) {
	
		Employee employee=null;
		Session session=null;
		
		try{
			
			session=HbernateUtil.openSession();
			Criteria criteria = session.createCriteria(Employee.class, "EMP")
					.createAlias("EMP.address", "ADDRESS");
			criteria.add(Restrictions.eq("EMP.empId",EmpId));
					
			employee =(Employee)criteria.list().get(0);
					
		}catch(Exception e){
			employee=null;
			e.printStackTrace();
			}
		finally{
			session.close();
		}
		return employee;
		
	}

	
	
	
}
