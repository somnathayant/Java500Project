package com.ayantsoft.empMgMt.employeeserviceImpl;

import java.io.Serializable;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ayantsoft.empMgMt.employeedaoImpl.EmployeeDaoImpl;
import com.ayantsoft.empMgMt.employeeservice.EmployeeService;
import com.ayantsoft.empMgMt.hibernate.pojo.Employee;

@Service
public class EmployeeServiceImpl implements Serializable,EmployeeService {

	/**
	 * serialVersionUID = -2933162031727467001L;
	 */
	private static final long serialVersionUID = -2933162031727467001L;

	@Autowired
	EmployeeDaoImpl employeeDaoImpl;
	
	@Override
	public boolean saveEmployee(Employee e) {
		
		boolean isEmpSaved=false;
		isEmpSaved=employeeDaoImpl.saveEmployee(e);
		return isEmpSaved;
	}

	@Override
	public List<Employee> emps() {
		EmployeeDaoImpl employeeDaoImpl=new EmployeeDaoImpl();
		return employeeDaoImpl.emps();
	}

	@Override
	public Employee getEmpById(Integer EmpId) {
		return employeeDaoImpl.getEmpById(EmpId);
		
	}

}
