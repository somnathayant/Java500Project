package com.ayantsoft.empMgMt.employeeservice;

import java.io.Serializable;
import java.util.List;


import com.ayantsoft.empMgMt.hibernate.pojo.Employee;

public interface EmployeeService extends Serializable {

	public boolean saveEmployee(Employee e);
	public List<Employee>emps();
	public Employee getEmpById(Integer EmpId);
	
}
