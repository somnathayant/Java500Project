/*package com.cg.api.service.test;


import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import org.junit.Test;
import org.junit.jupiter.api.extension.ExtendWith;
//import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import com.cg.api.controller.PocController;
import com.cg.api.dto.EmployeeDto;
import com.cg.api.pojo.Address;
import com.cg.api.pojo.Employee;
import com.cg.api.repository.AddressRepository;
import com.cg.api.repository.EmployeeRepository;
import com.cg.api.service.impl.EmployeeServiceImpl;
import static org.junit.Assert.assertEquals;


@ExtendWith(MockitoExtension.class)
@RunWith(MockitoJUnitRunner.class)
public class EmployeeServiceTest {

	
	 @InjectMocks
	 private EmployeeServiceImpl employeeService;
	 
	 @InjectMocks
	 private PocController pocController;
	
	@Mock
	EmployeeRepository mockedEmployeeRepository;
	
	@Mock
	AddressRepository mockedAddressRepository;
	
	
	@Test
	public void saveEmployeeTest() {
		
		try {
		Address ad=new Address();
		ad.setCity("bkr");
		ad.setAddressId(8);
		Employee emp=new Employee();
		emp.setName("somnath");
		emp.setAddress(ad);
		
		Employee emp1=new Employee();
		emp1.setName("govind");
		emp1.setAddress(ad);
		emp1.setEmpId(7);
		
		Mockito.lenient().when(mockedEmployeeRepository.save(any(Employee.class))).thenReturn(emp1);
		Mockito.lenient().when(mockedAddressRepository.save(any(Address.class))).thenReturn(emp1.getAddress());
		EmployeeDto ed=new EmployeeDto();
		ed.setName("somnath");
		ed.setCity("bkr");
		
		ResponseEntity<EmployeeDto>res=(ResponseEntity<EmployeeDto>) pocController.saveEmployee(ed);
		//Employee res=employeeService.saveEmployee(emp);
		
		  assertEquals(new Integer(10),res.getBody().getEmpId());
		}catch(Exception ex) {}
	}

}
*/