package com.cg.api.service.impl1;

public class EmpServiceImpl1 {

    public void test(){
        System.out.println("====");
    }


}
