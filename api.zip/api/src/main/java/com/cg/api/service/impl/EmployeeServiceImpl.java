package com.cg.api.service.impl;

import java.io.Serializable;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.api.pojo.Address;
import com.cg.api.pojo.Employee;
import com.cg.api.repository.AddressRepository;
import com.cg.api.repository.EmployeeRepository;
import com.cg.api.service.EmployeeService;


@Service
public class EmployeeServiceImpl implements Serializable,EmployeeService{

	/**
	 * serialVersionUID = 118132574227962057L;
	 */
	private static final long serialVersionUID = 118132574227962057L;

	@Autowired
	private EmployeeRepository employeeRepository;
	

	@Autowired
	private AddressRepository addressRepository;
	
	@Transactional
	@Override
	public Employee saveEmployee(Employee e) {//emp1
		// TODO Auto-generated method stub
		//employeeRepository.findAll();
		Address ad=addressRepository.save(e.getAddress());//code-->DBemp1.address
		Employee emp=employeeRepository.save(e);//emp1
		emp.setAddress(ad);
		return emp;
		
	}
	
	@Override
	public List<Employee>findAllEmployee(){
		
		return employeeRepository.findAll();
	
	}

	@Override
	public Employee getEmployeeById(Integer id) {
		// TODO Auto-generated method stub
		Employee emp=employeeRepository.getById(id);
		return emp;
	}

	@Override
	public Employee updateEmployee(Employee e) {
		// TODO Auto-generated method stub
		Address ad=addressRepository.save(e.getAddress());//code-->DBemp1.address
		Employee emp=employeeRepository.save(e);//emp1
		emp.setAddress(ad);
		return emp;
	}
}
