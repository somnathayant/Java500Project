/**
 * 
 */
/**
 * @author somnath Biswas
 *
 */
package com.cg.api.pojo;