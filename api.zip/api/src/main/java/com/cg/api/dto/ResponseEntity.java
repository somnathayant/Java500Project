package com.cg.api.dto;

public class ResponseEntity {

}
