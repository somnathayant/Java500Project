package com.cg.api.service;

import java.util.List;

import com.cg.api.pojo.Employee;

public interface EmployeeService {

	public Employee saveEmployee(Employee e);

	public List<Employee> findAllEmployee();
	public Employee getEmployeeById(Integer id);
	public Employee updateEmployee(Employee e);
}
