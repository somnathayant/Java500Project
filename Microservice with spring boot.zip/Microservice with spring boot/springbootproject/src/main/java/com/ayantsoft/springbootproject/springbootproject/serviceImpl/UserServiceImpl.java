package com.ayantsoft.springbootproject.springbootproject.serviceImpl;

import java.io.Serializable;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ayantsoft.springbootproject.springbootproject.model.Roles;
import com.ayantsoft.springbootproject.springbootproject.model.Student;
import com.ayantsoft.springbootproject.springbootproject.model.User;
import com.ayantsoft.springbootproject.springbootproject.repository.StudentRepository;
import com.ayantsoft.springbootproject.springbootproject.repository.UserRepository;
import com.ayantsoft.springbootproject.springbootproject.service.UserService;

@Service
public class UserServiceImpl implements UserService,Serializable {

	@Autowired
	private UserRepository userRepository;
	@Autowired
	private StudentRepository studentRepository;
	
	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -7291413829286621667L;

	@Override
	public Set<Roles> getRoles(Long userId) {
		Optional<User> usrObj1=userRepository.findById(userId);
		User usr1=usrObj1.get();
		Set<Roles>roles=usr1.getRoles();
		
		return roles;

	}

	@Override
	public Student saveStudent(Student st) {
		return studentRepository.save(st);
	}

	@Override
	public List<Student> getStudents() {
		return studentRepository.findAll();
	}

}
