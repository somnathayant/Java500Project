package com.codersdata.EmpManagement.dao;

import com.codersdata.EmpManagement.dto.EmpDto;

public interface EmpDao {
	public Boolean saveEmp(EmpDto empDto);
}
