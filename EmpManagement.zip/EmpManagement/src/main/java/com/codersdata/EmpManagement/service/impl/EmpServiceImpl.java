package com.codersdata.EmpManagement.service.impl;

import com.codersdata.EmpManagement.dto.EmpDto;
import com.codersdata.EmpManagement.service.EmpService;

public class EmpServiceImpl implements EmpService{

	@Override
	public Boolean saveEmp(EmpDto empDto) {
		// TODO Auto-generated method stub
		return null;
	}

}
