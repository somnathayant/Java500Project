package com.codersdata.EmpManagement.dto;

public class EmpDto {

	private Integer empId;
	private String name;
	private Double salary;
	
	private Integer  addressId;
	private String city;
	private String state;
	public Integer getEmpId() {
		return empId;
	}
	public void setEmpId(Integer empId) {
		this.empId = empId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Double getSalary() {
		return salary;
	}
	public void setSalary(Double salary) {
		this.salary = salary;
	}
	public Integer getAddressId() {
		return addressId;
	}
	public void setAddressId(Integer addressId) {
		this.addressId = addressId;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public EmpDto(Integer empId, String name, Double salary, Integer addressId, String city, String state) {
		super();
		this.empId = empId;
		this.name = name;
		this.salary = salary;
		this.addressId = addressId;
		this.city = city;
		this.state = state;
	}
	public EmpDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
}
