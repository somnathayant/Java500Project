package com.codersdata.EmpManagement.service;

import com.codersdata.EmpManagement.dto.EmpDto;

public interface EmpService {
	
	public Boolean saveEmp(EmpDto empDto);

}
