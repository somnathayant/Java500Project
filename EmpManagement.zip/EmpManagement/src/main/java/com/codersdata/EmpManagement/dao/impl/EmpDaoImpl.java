package com.codersdata.EmpManagement.dao.impl;

import com.codersdata.EmpManagement.dao.EmpDao;
import com.codersdata.EmpManagement.dto.EmpDto;

public class EmpDaoImpl implements EmpDao{

	@Override
	public Boolean saveEmp(EmpDto empDto) {
		// TODO Auto-generated method stub
		return null;
	}

}
