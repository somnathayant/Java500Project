import { Injectable, OnInit } from '@angular/core';

import { Observable } from 'rxjs/Observable';
import {  Http,   Headers,   RequestOptions,   RequestOptionsArgs} from '@angular/http';
import 'rxjs/Rx';
import {EmployeeDto} from './EmployeeDto.model';
import {ServerResponse} from '../serverResponse/serverResponse';

@Injectable()
export class EmpService {
  url: string;
  emp:EmployeeDto;
  constructor(private nativeHttp: Http) {

  }
  saveEmp(emp: EmployeeDto): Observable<ServerResponse> {
    this.url="http://localhost:8082/corsRestForAng4/saveEmpData";
    
     return this.nativeHttp.post(this.url,emp).map(res => res.json());
  }

  getEmpForUpdate(empId:number): Observable<EmployeeDto> {
    this.emp.empId=empId;
    this.url="http://localhost:8082/corsRestForAng4/findEmpById";
     return this.nativeHttp.put(this.url,this.emp).map(res => res.json());
  }

}