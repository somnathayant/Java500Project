export class ServerResponse{

    serverResponse:String;

    //getter and setter method

    get returnRes():String {
    return this.serverResponse;
  }
  set SettingRes(value:String) {
    this.serverResponse=value;
  }
}