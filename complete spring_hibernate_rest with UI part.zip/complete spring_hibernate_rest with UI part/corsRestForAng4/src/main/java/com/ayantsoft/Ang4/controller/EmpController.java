package com.ayantsoft.Ang4.controller;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.sql.Blob;

import org.apache.commons.io.IOUtils;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.ayantsoft.Ang4.hibernate.pojo.Address;
import com.ayantsoft.Ang4.hibernate.pojo.Dept;
import com.ayantsoft.Ang4.hibernate.pojo.Emp;
import com.ayantsoft.Ang4.hibernate.pojo.ImageWrapper;
import com.ayantsoft.Ang4.hibernate.util.HbernateUtil;
import com.ayantsoft.Ang4.model.EmployeeDto;
import com.ayantsoft.Ang4.response.Response;
import com.ayantsoft.Ang4.service.EmpService;
import com.ayantsoft.Ang4.utility.EmailSession;

import java.util.*;  
import javax.mail.*;  
import javax.mail.internet.*;
import javax.servlet.http.HttpServletResponse;
import javax.activation.*;  


//as the class is annotated using @RestController now all the controller methods can be accessd by ip address
@RestController
public class EmpController{


	@Autowired
	private EmpService empservice;

	@RequestMapping(value="/",method=RequestMethod.GET)
	public String index(){

		return "Server Running";
	}


	@RequestMapping(value="/saveEmpData",method=RequestMethod.POST)//http://localhost:8081/corsRestForAng4/saveEmpData
	public ResponseEntity<?> saveEmpData(@RequestBody EmployeeDto empDtoObj){//here data received using @requestBody

		
		System.out.println(empDtoObj.getName());

		HttpStatus httpStatus = null;
		Response res=new Response();
		try{

			Emp emp=new Emp();
			Address add=new Address();
			Dept dept=new Dept();

			emp.setName(empDtoObj.getName());
			emp.setDob(empDtoObj.getDob());
			emp.setSalary(empDtoObj.getSalary());

			add.setCity(empDtoObj.getCity());
			add.setPincode(empDtoObj.getPincode());
			add.setState(empDtoObj.getState());

			dept.setDeptName(empDtoObj.getDeptName());

			emp.setAddress(add);
			emp.setDept(dept);


			boolean isSaved=empservice.saveEmp(emp);

			if(isSaved) {
				httpStatus=HttpStatus.CREATED;
				
				res.setMsg("Employee created");
			}else {
				res.setMsg("Employee not created ; some problem occured ; please check status code");
			}
			return new ResponseEntity<Response>(res,httpStatus);
		}catch(Exception ex){
			httpStatus=HttpStatus.EXPECTATION_FAILED;
			res.setMsg("Employee not created ; some problem occured ; please check status code");
			return new ResponseEntity<Response>(res,httpStatus);
		}
	}

	
	@RequestMapping(value="/saveUpdatedEmpData",method=RequestMethod.POST)//http://localhost:8081/corsRestForAng4/getEmpData
	public ResponseEntity<?> saveUpdatedEmpData(@RequestBody EmployeeDto empDtoObj){//here data received using @requestBody

		
		System.out.println("in updation"+empDtoObj.getEmpId());

		HttpStatus httpStatus = null;
		Response res=new Response();
		try{

			Emp emp=new Emp();
			Address add=new Address();
			Dept dept=new Dept();
			
			emp.setId(empDtoObj.getEmpId());
			add.setId(empDtoObj.getAddressid());
			dept.setDeptId(empDtoObj.getDeptId());
			
			System.out.println("in updation"+emp.getId());
			
				
				
			emp.setName(empDtoObj.getName());
			emp.setDob(empDtoObj.getDob());
			emp.setSalary(empDtoObj.getSalary());

			add.setCity(empDtoObj.getCity());
			add.setPincode(empDtoObj.getPincode());
			add.setState(empDtoObj.getState());

			dept.setDeptName(empDtoObj.getDeptName());

			emp.setAddress(add);
			emp.setDept(dept);


			boolean isSaved=empservice.saveEmp(emp);

			if(isSaved) {
				httpStatus=HttpStatus.CREATED;
				
				res.setMsg("Employee created");
			}else {
				res.setMsg("Employee not created ; some problem occured ; please check status code");
			}
			return new ResponseEntity<Response>(res,httpStatus);
		}catch(Exception ex){
			httpStatus=HttpStatus.EXPECTATION_FAILED;
			res.setMsg("Employee not created ; some problem occured ; please check status code");
			return new ResponseEntity<Response>(res,httpStatus);
		}
	}

	
	
	
	
	
	@RequestMapping(value="/emps",method=RequestMethod.GET)
	public ResponseEntity<?> emps(){

		HttpStatus httpStatus = null;
		List<Emp>emps=null;
		List<EmployeeDto>empDtos=new ArrayList<EmployeeDto>();
		
		Response res=new Response();
		try {
			emps=empservice.emps();

			if(emps!=null) {
				httpStatus=HttpStatus.OK;
				for(Emp e:emps){
					EmployeeDto eDto=new EmployeeDto();
					
					eDto.setEmpId(e.getId());
					eDto.setName(e.getName());
					eDto.setSalary(e.getSalary());
					eDto.setDob(e.getDob());
					eDto.setCity(e.getAddress().getCity());
					eDto.setPincode(e.getAddress().getPincode());
					eDto.setState(e.getAddress().getState());
					eDto.setDeptName(e.getDept().getDeptName());
					
					empDtos.add(eDto);
				}
			}else if(emps.size()==0){
				httpStatus=HttpStatus.EXPECTATION_FAILED;
				res.setMsg("No Employee found ; some problem occured ; please check query or database");
				return new ResponseEntity<Response>(res,httpStatus);
			}
		}catch(Exception ex) {

			httpStatus=HttpStatus.EXPECTATION_FAILED;
			res.setMsg("No Employee list ; some problem occured ; please check status code");
			return new ResponseEntity<Response>(res,httpStatus);

		}
		return new ResponseEntity<List<EmployeeDto>>(empDtos,httpStatus);
	}

	@RequestMapping(value="/findEmpById",method=RequestMethod.PUT)//http://localhost:8081/corsRestForAng4/getEmpData
	public ResponseEntity<?> findEmpById(@RequestBody EmployeeDto empDtoObj){//here data received using @requestBody

		
		HttpStatus httpStatus = null;
		Emp emp=null;
		Emp emp1=new Emp();
		emp1.setId(empDtoObj.getEmpId());;
		Response res=new Response();
		try {
			emp=empservice.findEmpById(emp1);
			
			if(emp!=null) {
				httpStatus=HttpStatus.OK;
					
				empDtoObj.setAddressid(emp.getId());
				empDtoObj.setCity(emp.getAddress().getCity());
				empDtoObj.setAddressid(emp.getAddress().getId());
				empDtoObj.setDeptId(emp.getDept().getDeptId());
				empDtoObj.setDeptName(emp.getDept().getDeptName());
				empDtoObj.setDob(emp.getDob());
				empDtoObj.setName(emp.getName());
				empDtoObj.setPincode(emp.getAddress().getPincode());
				empDtoObj.setSalary(emp.getSalary());
				empDtoObj.setState(emp.getAddress().getState());
				return new ResponseEntity<EmployeeDto>(empDtoObj,httpStatus);
				}
		}catch(Exception ex) {

			httpStatus=HttpStatus.EXPECTATION_FAILED;
			res.setMsg("No Employee found ; some problem occured ; please check status code");
			return new ResponseEntity<Response>(res,httpStatus);

		}
		return new ResponseEntity<EmployeeDto>(empDtoObj,httpStatus);


	}

		
	@RequestMapping(value="/saveFile",headers=("content-type=multipart/*"),method=RequestMethod.POST)//http://localhost:8082/corsRestForAng4/saveFile
	public ResponseEntity<?> saveFile(@RequestParam("file") MultipartFile file ){
		HttpStatus httpStatus=null;
		httpStatus=HttpStatus.OK;
		Response res=new Response();
		try{
			System.out.println(file.getSize());
			File bFile = new File( file.getOriginalFilename());
			file.transferTo(bFile);

			byte[] dataFile = new byte[(int) bFile.length()];
			FileInputStream fileInputStream = new FileInputStream(bFile);
			//convert file into array of bytes
			fileInputStream.read(dataFile);
			fileInputStream.close();


			ImageWrapper d1=new ImageWrapper();

			d1.setData(dataFile);
			d1.setImageName(file.getOriginalFilename());
			d1.setContentType(file.getContentType());
			
			Session session=null;
			session=HbernateUtil.openSession();
			session.beginTransaction();

			session.save(d1);

			session.getTransaction().commit();

			res.setMsg("File saved succesfully");
		}catch(Exception ex){
			httpStatus=HttpStatus.NOT_ACCEPTABLE;
			res.setMsg("File not saved succesfully");
		}
		return new ResponseEntity<Response>(res,httpStatus);
	}

	@RequestMapping(value="/downloadFile",method=RequestMethod.POST,produces = "application/pdf")//http://localhost:8081/corsRestForAng4/downloadFile
	public ResponseEntity<?> downloadFile(@RequestBody EmployeeDto empDtoObj){
		HttpStatus httpStatus=null;
		httpStatus=HttpStatus.OK;
		Response res=new Response();
		ImageWrapper imageWrapperObj=new ImageWrapper();
		try{
			System.out.println(empDtoObj.getEmpId());
			imageWrapperObj=empservice.downloadFile(empDtoObj.getEmpId());
			
			if(imageWrapperObj!=null){
				/*response.setHeader("Content-Disposition", "inline;filename=\"" +imageWrapperObj.getImageName()+ "\"");
				OutputStream out = response.getOutputStream();
				ByteArrayInputStream bis = new ByteArrayInputStream(imageWrapperObj.getData());

				response.setContentType(imageWrapperObj.getContentType());
				IOUtils.copy(bis, out);
				out.flush();
				out.close();*/
				System.out.println("========");
				  				 
				return ResponseEntity.ok()
						  .contentType(MediaType.parseMediaType("application/pdf"))
				          .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + imageWrapperObj.getImageName() + "\"")
				          .body(imageWrapperObj.getData()); 
			}
			
			
		}catch(Exception ex){
			res.setMsg("File not found");
		}
		return new ResponseEntity<Response>(res,httpStatus);
	}

	
	
	
	
	
	
	@RequestMapping(value="/sendEmail",method=RequestMethod.GET)
	public ResponseEntity<?> sendEmail(){

		HttpStatus httpStatus=null;
		httpStatus=HttpStatus.OK;
		Response res=new Response();


		try{
			
			String to="biswassomnath39@gmail.com";//change accordingly  
			final String user="som.biswas10@gmail.com";//change accordingly  
			final String password="somnath@biswas123";//change accordingly  

			
			EmailSession ems=new EmailSession();

			//2) compose message     

			MimeMessage message = new MimeMessage(ems.createEmailSession());  
			message.setFrom(new InternetAddress(user));  
			message.addRecipient(Message.RecipientType.TO,new InternetAddress(to));  
			message.setSubject("Salary Aleart");  

			//3) create MimeBodyPart object and set your message text     
			BodyPart messageBodyPart1 = new MimeBodyPart();  
			messageBodyPart1.setText("Dear User," +
					"nn Please find attached file for salary log. This mail tutorial really nice, please try it!!!");  

			//4) create new MimeBodyPart object and set DataHandler object to this object      
			MimeBodyPart messageBodyPart2 = new MimeBodyPart();  

			String filename = "/home/somnath/Desktop/exam fee.png";//change accordingly  
			DataSource source = new FileDataSource(filename);  
			messageBodyPart2.setDataHandler(new DataHandler(source));  
			messageBodyPart2.setFileName(filename);  


			//5) create Multipart object and add MimeBodyPart objects to this object      
			Multipart multipart = new MimeMultipart();  
			multipart.addBodyPart(messageBodyPart1);  
			multipart.addBodyPart(messageBodyPart2);  

			//6) set the multiplart object to the message object  
			message.setContent(multipart );  

			//7) send message  
			Transport.send(message);  

			System.out.println("message sent....");  
			httpStatus=HttpStatus.OK;
			res.setMsg("Email has been sent");

		}catch(Exception ex){

			httpStatus=HttpStatus.EXPECTATION_FAILED;
			res.setMsg("No Email sent");
			return new ResponseEntity<Response>(res,httpStatus);

		}

		return new ResponseEntity<Response>(res,httpStatus);


	}





}
