package com.ayantsoft.Ang4.hibernate.pojo;

import static javax.persistence.GenerationType.IDENTITY;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "TBL_IMAGES",catalog = "employee1")
public class ImageWrapper implements Serializable {

	private static final long serialVersionUID = 1L;


	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "ID", unique = true, nullable = false)
	private Integer id;

	@Column(name = "IMAGE_NAME", unique = false, nullable = false, length = 100)
	private String imageName;

	@Column(name = "CONTENT_TYPE", unique = false, nullable = false, length = 100)
	private String contentType;

	@Column(name = "DATA", unique = false, nullable = false, length = 100000)
	private byte[] data;



	public ImageWrapper(){

	}

	public ImageWrapper(Integer id,String imageName,byte[] data,String contentType){
			
			this.id=id;
			this.imageName=imageName;
			this.data=data;
			this.contentType=contentType;
	}




	//Getters and Setters

	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getImageName() {
		return imageName;
	}

	public void setImageName(String imageName) {
		this.imageName = imageName;
	}

	public byte[] getData() {
		return data;
	}

	public void setData(byte[] data) {
		this.data = data;
	}





}