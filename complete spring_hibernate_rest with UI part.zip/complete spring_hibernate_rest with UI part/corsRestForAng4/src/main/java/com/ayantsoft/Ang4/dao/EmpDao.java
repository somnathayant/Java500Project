package com.ayantsoft.Ang4.dao;

import java.io.Serializable;
import java.util.List;

import com.ayantsoft.Ang4.hibernate.pojo.Emp;
import com.ayantsoft.Ang4.hibernate.pojo.ImageWrapper;

public interface EmpDao extends Serializable{
	public boolean saveEmployee(Emp emp);
	public List<Emp>emps();
	public ImageWrapper downloadFile(Integer empId);
	public Emp findEmpById(Emp emp);
	
}
