package com.ayantsoft.Ang4.daoImpl;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.ayantsoft.Ang4.dao.EmpDao;
import com.ayantsoft.Ang4.hibernate.pojo.Emp;
import com.ayantsoft.Ang4.hibernate.pojo.ImageWrapper;
import com.ayantsoft.Ang4.hibernate.util.HbernateUtil;

@Repository
public class EmpDaoImpl implements Serializable,EmpDao{

	/**
	 * serialVersionUID 
	 */
	private static final long serialVersionUID = -5881871931455856231L;
	

	@Override
	public boolean saveEmployee(Emp emp) {
		
		Session session=null;
		boolean isEmpSaved=false;
		try{
			session=HbernateUtil.openSession();
			session.beginTransaction();
			System.out.println("at Dao"+emp.getId());
			if(emp.getId()==null){
			session.save(emp.getAddress());
			session.save(emp.getDept());
			session.save(emp);
			isEmpSaved=true;
			}else{
				System.out.println("======");
				session.update(emp.getAddress());
				session.update(emp.getDept());
				session.update(emp);
				isEmpSaved=true;
			
			}
			
		session.getTransaction().commit();
		}catch(Exception ex){ex.printStackTrace();
		
		session.getTransaction().rollback();
		}finally{
			session.close();
		}
		
		
		return isEmpSaved;
	}


	@SuppressWarnings("unchecked")
	@Override
	public List<Emp> emps() {
		
		List<Emp> employees=null;
		Session session=null;
		try{
			//inner join of criteria
			session=HbernateUtil.openSession();
			Criteria criteria = session.createCriteria(Emp.class, "EMP")
					.createAlias("EMP.address", "ADDRESS")
					.createAlias("EMP.dept", "DEPT");
			employees =criteria.list();
			
			
			/*here both the approach is done above with criteria  and below with HQL
			 * only emp and address table is used one can add other tables as well
			 * 
			 * */
			
			/*session=HbernateUtil.openSession();
			
			String hql = "FROM Emp EMP "
					+ "JOIN FETCH  EMP.address ADD";
					
			Query query = session.createQuery(hql);
			
			employees = ((List<Emp>) query.list());
*/
		
		}catch(Exception e){
			employees=null;
			e.printStackTrace();
			}
		finally{
			session.close();
		}
		return employees;
		
	}


	@Override
	public ImageWrapper downloadFile(Integer empId) {
		
		Session session=null;
		ImageWrapper imageWrapper;
		try{
			
			session=HbernateUtil.openSession();
			Criteria criteria = session.createCriteria(ImageWrapper.class, "IMG")
					.add(Restrictions.eq("IMG.id",empId));
			imageWrapper =(ImageWrapper )criteria.uniqueResult();
	
		}catch(Exception e){
			imageWrapper=null;
			e.printStackTrace();
			}
		finally{
			session.close();
		}
		return imageWrapper;
		
		
	}


	@Override
	public Emp findEmpById(Emp emp) {
		
		Session session=null;
		Emp empObj=null;
		try{
			
			session=HbernateUtil.openSession();
			Criteria criteria = session.createCriteria(Emp.class, "EMP")
					.createAlias("EMP.address","ADD")
					.createAlias("EMP.dept","DEPT")
					.add(Restrictions.eq("EMP.id",emp.getId()));
					empObj =(Emp )criteria.uniqueResult();
	
		}catch(Exception e){
			empObj=null;
			e.printStackTrace();
			}
		finally{
			session.close();
		}
		return empObj;
		
		
	}

	
	
	
	
}
