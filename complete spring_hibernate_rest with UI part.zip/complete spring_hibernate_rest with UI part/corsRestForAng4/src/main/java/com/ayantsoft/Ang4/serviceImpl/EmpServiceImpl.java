package com.ayantsoft.Ang4.serviceImpl;

import java.io.Serializable;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ayantsoft.Ang4.dao.EmpDao;
import com.ayantsoft.Ang4.hibernate.pojo.Emp;
import com.ayantsoft.Ang4.hibernate.pojo.ImageWrapper;
import com.ayantsoft.Ang4.service.EmpService;


@Service
public class EmpServiceImpl implements Serializable,EmpService {

	/**
	 * serialVersionUID 
	 */
	private static final long serialVersionUID = 6396566231641097813L;
	@Autowired
	private EmpDao empDao;
	
	@Override
	public boolean saveEmp(Emp emp) {
		
		return empDao.saveEmployee(emp);
	}

	@Override
	public List<Emp> emps() {
		
		return empDao.emps();
	}

	@Override
	public ImageWrapper downloadFile(Integer empId) {
		
		return empDao.downloadFile(empId);
	}

	@Override
	public Emp findEmpById(Emp emp) {
		
		return empDao.findEmpById(emp);
	}

	
}
