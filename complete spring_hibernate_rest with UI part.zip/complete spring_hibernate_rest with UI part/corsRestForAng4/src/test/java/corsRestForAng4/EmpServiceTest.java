package corsRestForAng4;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.ayantsoft.Ang4.daoImpl.EmpDaoImpl;
import com.ayantsoft.Ang4.hibernate.pojo.Emp;
import com.ayantsoft.Ang4.serviceImpl.EmpServiceImpl;


public class EmpServiceTest {

	@InjectMocks
	EmpServiceImpl empService;
     
    @Mock
    EmpDaoImpl empDao;
	
    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }
    
    @Test
    public void testSaveEmployee(){
    	
    	
    	Emp e=new Emp();
    	//when(empDao.saveEmployee(e)).thenReturn(true);
    	
    	boolean isSaved=empService.saveEmp(e);
    	
    	assertEquals(true,isSaved);
    }

	
    
    
    
    
}
