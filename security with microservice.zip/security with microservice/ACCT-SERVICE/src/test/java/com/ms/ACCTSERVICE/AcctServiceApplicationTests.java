package com.ms.ACCTSERVICE;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AcctServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
