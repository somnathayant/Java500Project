package com.ms.GATEWAYSERVER;

import java.nio.charset.StandardCharsets;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;

@RestController
@RequestMapping("/users")
public class AuthController {
	
	 @Value("${jwt.secret}")
	 private String jwtSecret;
	
    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;  // BCryptPasswordEncoder bean

    @PostMapping("/create")
    public ResponseEntity<String> createUser(@RequestBody User request) {
        if (userRepository.existsByUserId(request.getUserId())) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body("User already exists");
        }

        User user = new User();
        user.setUserId(request.getUserId());
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        user.setUserRoles(request.getUserRoles()); // expects e.g. "ROLE_U,ROLE_M"

        userRepository.save(user);
        return ResponseEntity.ok("User created successfully");
    }
    
    @PostMapping("/authenticate")
    public ResponseEntity<?> authenticate(@RequestBody AuthReq authRequest) {
        User user = userRepository.findByUserId(authRequest.getUserId());
        if (user == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid userId or password");
        }

        if (!passwordEncoder.matches(authRequest.getPassword(), user.getPassword())) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid userId or password");
        }

        String token = generateToken(user.getUserId());

        return ResponseEntity.ok(new AuthRes(token));
    }

    private String generateToken(String userId) {
        return Jwts.builder()
                .setSubject(userId)
                .signWith(Keys.hmacShaKeyFor(jwtSecret.getBytes(StandardCharsets.UTF_8)))
                .compact();
    }

    
    
    
    
}
