package com.ms.GATEWAYSERVER;





import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import reactor.core.publisher.Mono;


/*
 * @Component
 * 
 * @Order(0) public class AuthenticationFilter implements GlobalFilter {
 * 
 * @Autowired private RestTemplate restTemplate;
 * 
 * private static final Logger logger =
 * LoggerFactory.getLogger(AuthenticationFilter.class);
 * 
 * @Override public Mono<Void> filter(ServerWebExchange exchange,
 * org.springframework.cloud.gateway.filter.GatewayFilterChain chain) {
 * logger.info("Global Filter executed for request: {}",
 * exchange.getRequest().getPath());
 * 
 * ServerHttpRequest request = (ServerHttpRequest) exchange.getRequest();
 * List<String> apiEndpoints = Arrays.asList("SECURITY-SERVICE");
 * Predicate<ServerHttpRequest> isApiSecured = r -> apiEndpoints.stream()
 * .noneMatch(uri -> r.getURI().getPath().contains(uri));
 * 
 * if (isApiSecured.test(request)) { if
 * (!request.getHeaders().containsKey("Authorization")) { ServerHttpResponse
 * response = exchange.getResponse();
 * response.setStatusCode(HttpStatus.UNAUTHORIZED);
 * 
 * return response.setComplete(); }
 * logger.info("Global Filter executed for request: 1{}",
 * exchange.getRequest().getPath());
 * 
 * HttpHeaders header = new HttpHeaders(); final String token =
 * exchange.getRequest().getHeaders().getOrEmpty("Authorization").get(0);
 * logger.info("token {}",token); header.add("Authorization",token);
 * logger.info("Global Filter executed for request: 2{}", token); try {
 * ResponseEntity<String> response = restTemplate.exchange(
 * "http://localhost:8080/SECURITY-SERVICE/"+exchange.getRequest().getPath(),
 * HttpMethod.GET, new HttpEntity<>(String.class, header), String.class);
 * }catch(Exception ex) { logger.info("Global Filter executed for request: 4{}",
 * token); ServerHttpResponse responseReturn = (ServerHttpResponse)
 * exchange.getResponse(); ((ServerHttpResponse)
 * responseReturn).setStatusCode(HttpStatus.FORBIDDEN); return
 * ((ReactiveHttpOutputMessage) responseReturn).setComplete(); }
 * 
 * } return chain.filter(exchange); } }
 */ 
@Component
public class AuthenticationFilter implements GatewayFilter {

    @Value("${jwt.secret}")
    private String jwtSecret;

    @Autowired
    private UserRepository userRepository;

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
        ServerHttpRequest request = exchange.getRequest();
        String path = request.getURI().getPath();

        // Permit all for "/" and "/SECURITY-SERVICE/authenticate"
        if (path.equals("/") || path.equals("/users/create") || path.equals("/users/authenticate")) {
            return chain.filter(exchange);
        }

        // Check Authorization header presence and validity
        if (!request.getHeaders().containsKey("Authorization")) {
            return onError(exchange, "Missing Authorization header", HttpStatus.UNAUTHORIZED);
        }
        String authHeader = request.getHeaders().getFirst("Authorization");
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            return onError(exchange, "Invalid Authorization header", HttpStatus.BAD_REQUEST);
        }
        String token = authHeader.substring(7);

        try {
            Claims claims = validateToken(token);
            String username = claims.getSubject();

            Optional<User> userOpt = Optional.ofNullable(userRepository.findByUserId(username));
            if (userOpt.isEmpty()) {
                return onError(exchange, "User not found", HttpStatus.UNAUTHORIZED);
            }

            List<String> userRoles = Arrays.stream(userOpt.get().getUserRoles().split(","))
                    .map(String::trim)
                    .map(role -> role.startsWith("ROLE_") ? role : "ROLE_" + role) // Ensure roles have "ROLE_" prefix
                    .toList();

            // Role checks based on path
            if (path.equals("/ACCT-SERVICE/getUser")) {
                if (!userRoles.contains("ROLE_U")) {
                    return onError(exchange, "Forbidden", HttpStatus.FORBIDDEN);
                }
            } else if (path.equals("/ACCT-SERVICE/getAdmin")
                    || path.equals("/ACCT-SERVICE/getAll")) {
                if (!userRoles.contains("ROLE_M")) {
                    return onError(exchange, "Forbidden", HttpStatus.FORBIDDEN);
                }
            } else {
                // For any other path, just check user is authenticated (already validated JWT)
                // You can add additional role checks here if required
            }

            // Forward username downstream
            ServerHttpRequest mutatedRequest = request.mutate()
                    .header("X-User", username)
                    .build();

            return chain.filter(exchange.mutate().request(mutatedRequest).build());

        } catch (Exception e) {
            return onError(exchange, "Unauthorized: " + e.getMessage(), HttpStatus.UNAUTHORIZED);
        }
    }

    private Claims validateToken(String token) {
        return Jwts.parserBuilder()
                .setSigningKey(Keys.hmacShaKeyFor(jwtSecret.getBytes(StandardCharsets.UTF_8)))
                .build()
                .parseClaimsJws(token)
                .getBody();
    }

    private Mono<Void> onError(ServerWebExchange exchange, String message, HttpStatus status) {
        ServerHttpResponse response = exchange.getResponse();
        response.setStatusCode(status);
        byte[] bytes = message.getBytes(StandardCharsets.UTF_8);
        return response.writeWith(Mono.just(response.bufferFactory().wrap(bytes)));
    }
}