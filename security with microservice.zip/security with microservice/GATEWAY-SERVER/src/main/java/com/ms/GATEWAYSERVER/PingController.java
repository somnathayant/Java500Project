package com.ms.GATEWAYSERVER;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class PingController {

	@GetMapping("/")
	public String ping() {
		 System.out.println("=====yyy");
		return "ok1";
	}
}
