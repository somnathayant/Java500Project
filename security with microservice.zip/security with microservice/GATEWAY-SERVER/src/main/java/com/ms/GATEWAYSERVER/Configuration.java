package com.ms.GATEWAYSERVER;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;



@org.springframework.context.annotation.Configuration
public class Configuration {
	
	@Autowired
	private AuthenticationFilter authenticationFilter;
	
	@Bean 
	public RestTemplate restTemplate(){
	    return new RestTemplate();
	}
	
	
	/*
	 * @Bean public RouteLocator configureRoute(RouteLocatorBuilder builder) {
	 * return builder.routes() .route("EMP-SERVICE", r->r.path("/EMP-SERVICE/**")
	 * //.filters(f -> f.filter((GatewayFilter) jwtFilter))
	 * .uri("lb://EMP-SERVICE")) .route("ACCT-SERVICE",
	 * r->r.path("/ACCT-SERVICE/**") //.filters(f -> f.filter((GatewayFilter)
	 * jwtFilter)) .uri("lb://ACCT-SERVICE")) //dynamic routing
	 * .route("SECURITY-SERVICE", r->r.path("/SECURITY-SERVICE/**")
	 * .uri("lb://SECURITY-SERVICE")) //dynamic routing .build(); }
	 */
	
	@Bean
	public RouteLocator configureRoute(RouteLocatorBuilder builder) {
	    return builder.routes()
	        .route("SECURITY-SERVICE", r -> r.path("/SECURITY-SERVICE/**")
	                .filters(f -> f.filter(authenticationFilter))
	                .uri("lb://SECURITY-SERVICE"))
	        .route("EMP-SERVICE", r -> r.path("/EMP-SERVICE/**")
	                .filters(f -> f.filter(authenticationFilter))
	                .uri("lb://EMP-SERVICE"))
	        .route("ACCT-SERVICE", r -> r.path("/ACCT-SERVICE/**")
	                .filters(f -> f.filter(authenticationFilter))
	                .uri("lb://ACCT-SERVICE"))
	        .build();
	}
	
}
