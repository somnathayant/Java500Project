package com.ayantsoft.springbootproject.springbootproject.controller;

import java.io.Serializable;

import javax.persistence.ColumnResult;
import javax.persistence.MappedSuperclass;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.*;

@MappedSuperclass
@SqlResultSetMapping(name = "StudentDto", classes = @ConstructorResult(targetClass = com.ayantsoft.springbootproject.springbootproject.controller.StudentDto.class, columns = { @ColumnResult(name = "first", type = String.class),
        @ColumnResult(name = "city", type = String.class) }))
public class StudentDto implements Serializable{

	/**
	 * long serialVersionUID = -4447768577511358930L;
	 */
	private static final long serialVersionUID = -4447768577511358930L;
	private String first;
	private String city;
	
	
	
	/*public StudentDto(Object ob) throws NoSuchFieldException, SecurityException {
		super();
		this.city=ob.getClass().getField(first).toString();
		this.first=ob.getClass().getField(city).toString();
	}
*/
	public StudentDto(String first, String city) {
		super();
		this.first = first;
		this.city = city;
	}

	public String getFirst() {
		return first;
	}

	public void setFirst(String first) {
		this.first = first;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}
	
	
	
	
	
}
