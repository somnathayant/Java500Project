/*package com.ayantsoft.springbootproject.springbootproject.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ayantsoft.springbootproject.springbootproject.model.Student;

public interface StudentRepo extends <Student, Long>{

}
*/