package com.ayantsoft.springbootproject.springbootproject.serviceImpl;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Properties;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.StoredProcedureQuery;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ayantsoft.springbootproject.springbootproject.controller.StudentDto;
import com.ayantsoft.springbootproject.springbootproject.model.Roles;
import com.ayantsoft.springbootproject.springbootproject.model.StProjection;
import com.ayantsoft.springbootproject.springbootproject.model.Student;
import com.ayantsoft.springbootproject.springbootproject.model.User;
import com.ayantsoft.springbootproject.springbootproject.repository.AddressRepository;
import com.ayantsoft.springbootproject.springbootproject.repository.StudentRepository;
import com.ayantsoft.springbootproject.springbootproject.repository.UserRepository;
import com.ayantsoft.springbootproject.springbootproject.service.UserService;

@Service
public class UserServiceImpl implements UserService,Serializable {

	@Autowired
	private UserRepository userRepository;
	@Autowired
	private StudentRepository studentRepository;
	@Autowired
	private AddressRepository addressRepository;
	
	@PersistenceContext
    private EntityManager entityManager;
	
	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -7291413829286621667L;

	@Override
	public Set<Roles> getRoles(Long userId) {
		Optional<User> usrObj1=userRepository.findById(userId);
		User usr1=usrObj1.get();
		Set<Roles>roles=usr1.getRoles();
		
		return roles;

	}
	
	@Transactional
	@Override
	public Student saveStudent(Student st) {
		
		
		
		
		
		addressRepository.save(st.getAddress());
		return studentRepository.save(st);
	}

	@Override
	public List<Student> getStudents() {
		return studentRepository.findAll();
	}

	
	
	
	
	@Override
	public List<StProjection> getStudentsWithCity(Long id) {
		// TODO Auto-generated method stub
		return studentRepository.getStudentsWithCity(id);
	}

	@Override
	@Transactional
	public List<StudentDto> findStudentWithCity() {
		 List<StudentDto> list = new ArrayList<>();
	        StoredProcedureQuery query = entityManager.createStoredProcedureQuery("getStudentsData", "StudentDto");
	        try {
	            // Execute query
	            query.execute();
	            list = query.getResultList();
	        }catch(Exception ex) {
	        	
	        }
	        return list;
	}

}

