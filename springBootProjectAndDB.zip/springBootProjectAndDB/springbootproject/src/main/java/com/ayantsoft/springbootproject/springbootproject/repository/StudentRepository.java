package com.ayantsoft.springbootproject.springbootproject.repository;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.ayantsoft.springbootproject.springbootproject.controller.StudentDto;
import com.ayantsoft.springbootproject.springbootproject.model.StProjection;
import com.ayantsoft.springbootproject.springbootproject.model.Student;


/*public interface StudentRepository extends CrudRepository<Student, Long> {

}*/


public interface StudentRepository extends JpaRepository<Student, Long>,Serializable {
		
	
	/*@Query("SELECT t.title FROM Todo t where t.id = :id") 
    String findTitleById(@Param("id") Long id);
   */
		@Query("SELECT st.year FROM Student st where st.id <= :id")
		public Iterable<Student>getStudentsLessThanOrEqualParam(@Param("id") Long id);
		
		//"select new com.QuestionDto(q.id, q.topic, q.views, ud.username, ur.points) from QuestionEntity q join UserDetails ud ON q.userId = ud.userId join userRanking ur ON ud.userId = ur.userId where q.id = :id"
		
		@Query("SELECT new com.ayantsoft.springbootproject.springbootproject.model.StProjection(st.id,a.city) FROM Student st   join  Address a on st.id=a.add_id  where st.id <= :id")
		public List<StProjection> getStudentsWithCity(@Param("id") Long id);
		
		@Query(value = "CALL getStudentsData();", nativeQuery = true)
		List<Object> findStudentWithCity();


		
}