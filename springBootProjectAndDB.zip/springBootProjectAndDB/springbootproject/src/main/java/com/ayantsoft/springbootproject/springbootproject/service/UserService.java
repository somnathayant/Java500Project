package com.ayantsoft.springbootproject.springbootproject.service;

import java.io.Serializable;
import java.util.List;
import java.util.Set;

import com.ayantsoft.springbootproject.springbootproject.controller.StudentDto;
import com.ayantsoft.springbootproject.springbootproject.model.Roles;
import com.ayantsoft.springbootproject.springbootproject.model.StProjection;
import com.ayantsoft.springbootproject.springbootproject.model.Student;

public interface UserService extends Serializable{
				
	public Set<Roles> getRoles(Long UserId);
	public Student saveStudent(Student st);
	public List<Student>getStudents();
	
	public List<StProjection>getStudentsWithCity(Long id);
	
	public List<StudentDto>findStudentWithCity();
	
}
