package com.ayantsoft.springbootproject.springbootproject.unit.test;

public class TestStudentService {

}
