package com.ayantsoft.springbootproject.springbootproject;


import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootprojectApplicationTests {

	@org.junit.Test
	void contextLoads() {
	}

}
