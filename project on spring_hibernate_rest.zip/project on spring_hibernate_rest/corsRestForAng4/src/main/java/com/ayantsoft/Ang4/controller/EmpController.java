package com.ayantsoft.Ang4.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.ayantsoft.Ang4.hibernate.pojo.Address;
import com.ayantsoft.Ang4.hibernate.pojo.Dept;
import com.ayantsoft.Ang4.hibernate.pojo.Emp;
import com.ayantsoft.Ang4.model.EmployeeDto;
import com.ayantsoft.Ang4.response.Response;
import com.ayantsoft.Ang4.service.EmpService;

//as the class is annotated using @RestController now all the controller methods can be accessd by ip address
@RestController
public class EmpController{


	@Autowired
	private EmpService empservice;

	@RequestMapping(value="/",method=RequestMethod.GET)
	public String index(){
		
		return "Server Running";
	}


	@RequestMapping(value="/saveEmpData",method=RequestMethod.POST)//http://localhost:8081/corsRestForAng4/getEmpData
	public ResponseEntity<?> saveEmpData(@RequestBody EmployeeDto empDtoObj){//here data received using @requestBody


		HttpStatus httpStatus = null;
		Response res=new Response();
		try{

			Emp emp=new Emp();
			Address add=new Address();
			Dept dept=new Dept();

			emp.setName(empDtoObj.getName());
			emp.setDob(empDtoObj.getDob());
			emp.setSalary(empDtoObj.getSalary());

			add.setCity(empDtoObj.getCity());
			add.setPincode(empDtoObj.getPincode());
			add.setState(empDtoObj.getState());

			dept.setDeptName(empDtoObj.getDeptName());

			emp.setAddress(add);
			emp.setDept(dept);


			boolean isSaved=empservice.saveEmp(emp);

			if(isSaved) {
				httpStatus=HttpStatus.CREATED;
				res.setMsg("Employee created");
			}else {
				res.setMsg("Employee not created ; some problem occured ; please check status code");
			}
			return new ResponseEntity<Response>(res,httpStatus);
		}catch(Exception ex){
			httpStatus=HttpStatus.EXPECTATION_FAILED;
			res.setMsg("Employee not created ; some problem occured ; please check status code");
			return new ResponseEntity<Response>(res,httpStatus);
		}
	}

	@RequestMapping(value="/emps",method=RequestMethod.GET)
	public ResponseEntity<?> emps(){

		HttpStatus httpStatus = null;
		List<Emp>emps=null;
		Response res=new Response();
		try {
			emps=empservice.emps();
			
			if(emps!=null) {
				httpStatus=HttpStatus.OK;
				System.out.println(emps.size());
				for(Emp e:emps){
					System.out.println(e.getName());
					System.out.println(e.getAddress().getCity());
					System.out.println(e.getDept().getDeptName());
				}
			}else if(emps.size()==0){
				res.setMsg("No Employee found ; some problem occured ; please check query or database");
				return new ResponseEntity<Response>(res,httpStatus);
			}
		}catch(Exception ex) {

			httpStatus=HttpStatus.EXPECTATION_FAILED;
			res.setMsg("No Employee list ; some problem occured ; please check status code");
			return new ResponseEntity<Response>(res,httpStatus);

		}
		return new ResponseEntity<List<Emp>>(emps,httpStatus);
	}



}
