package com.ayantsoft.Ang4.model;

import java.io.Serializable;
import java.util.Date;

import com.ayantsoft.Ang4.hibernate.pojo.Address;
import com.ayantsoft.Ang4.hibernate.pojo.Dept;

public class EmployeeDto implements Serializable{

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 8915609537711372378L;

	private Integer empId;
	private Integer addressid;
	private Integer deptId;
	private Address address;
	private Dept dept;
	private String name;
	private Date dob;
	private Integer salary;
	private String city;
	private String state;
	private Integer pincode;
	private String deptName;

	//getter and setter


	public Integer getEmpId() {
		return empId;
	}
	public void setEmpId(Integer empId) {
		this.empId = empId;
	}
	public Integer getAddressid() {
		return addressid;
	}
	public void setAddressid(Integer addressid) {
		this.addressid = addressid;
	}
	public Integer getDeptId() {
		return deptId;
	}
	public void setDeptId(Integer deptId) {
		this.deptId = deptId;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public Dept getDept() {
		return dept;
	}
	public void setDept(Dept dept) {
		this.dept = dept;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public Integer getSalary() {
		return salary;
	}
	public void setSalary(Integer salary) {
		this.salary = salary;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public Integer getPincode() {
		return pincode;
	}
	public void setPincode(Integer pincode) {
		this.pincode = pincode;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}







}
