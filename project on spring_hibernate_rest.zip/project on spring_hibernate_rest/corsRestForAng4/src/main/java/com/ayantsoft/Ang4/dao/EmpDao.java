package com.ayantsoft.Ang4.dao;

import java.io.Serializable;
import java.util.List;

import com.ayantsoft.Ang4.hibernate.pojo.Emp;

public interface EmpDao extends Serializable{
	public boolean saveEmployee(Emp emp);
	
	public List<Emp>emps();
	
}
