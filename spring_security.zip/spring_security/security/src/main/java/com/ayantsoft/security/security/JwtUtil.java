package com.ayantsoft.security.security;

import java.io.Serializable;

public class JwtUtil implements Serializable{

	/**
	 * long serialVersionUID = 2088968559326719836L;
	 */
	private static final long serialVersionUID = 2088968559326719836L;

	
	
	
	
	
	
	
}
