package com.ayantsoft.security.security;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AdminController {

	@GetMapping("/")
	public String ping() {
		
		return "server running";
	}
	@GetMapping("/getUser")
	public String ping1() {
		
		return "User";
	}
	@GetMapping("/getAdmin")
	public String ping2() {
		
		return "admin";
	}
	@GetMapping("/getAny")
	public String ping3() {
		
		return "user or admin";
	}
}
