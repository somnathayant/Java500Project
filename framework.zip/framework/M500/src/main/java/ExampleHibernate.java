import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.transform.Transformers;


import com.ayantsoft.hibernate.pojo.Address;
import com.ayantsoft.hibernate.pojo.Dept;
import com.ayantsoft.hibernate.pojo.Emp;
import com.ayantsoft.hibernate.util.HbernateUtil;



public class ExampleHibernate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hibernate is running");
		Session session=null;
		/*try{
		 session=HbernateUtil.openSession();
			
		session.beginTransaction();
		
		Emp e=new Emp();
		Address add=new Address();
		Dept d=new Dept();
		
		e.setName("Somnath Biswas");
		e.setEmail("som@gmail.com");
		
		add.setCity("Alabama");
		add.setPin(221133);
		add.setState("Alabama");
		
		d.setName("comp.Sc");
		
		e.setAddress(add);
		e.setDept(d);
		
		session.save(add);
		
		session.save(d);
		
		session.save(e);
		
		List<Emp> ar=new ArrayList<Emp>();
		
		for(Emp e1:ar){
			
			session.save(e1);
		}
		
		session.getTransaction().commit();
		}
		catch(Exception ex){
			session.getTransaction().rollback();
		}
	*/
		/* session.beginTransaction();
		 
		 Criteria criteria = session.createCriteria(Emp.class,"EMP");
	        criteria.createAlias("EMP.address", "ADDRESS");
	        
	        
	        criteria.setProjection(Projections.projectionList()
	                    .add(Projections.property("id").as( "id"))
	                    .add(Projections.property("name").as("name"))
	                    .add(Projections.property("password").as("password"))
	                    .add(Projections.property("email").as("email"))
	                    .add(Projections.property("ADDRESS.city").as("city"))
	        );
	        criteria.setResultTransformer(Transformers.aliasToBean(EmpDto.class));
		List<EmpDto>eList=criteria.list();
		System.out.println(eList.size());
		
		Iterator <EmpDto>it= eList.iterator();
		while(it.hasNext()){
			System.out.println(it.next());
		}
		
		session.getTransaction().commit();
		}*/
		 
		 
		 
		/* try{
			 session=HbernateUtil.openSession();
		   session.beginTransaction();
		
		 Emp e=(Emp)session.get(Emp.class,new Integer(5));
		 
		Query addressQuery = session.createQuery(""
				+ "UPDATE "
				+ "Address "

				+ "SET "						
				+ "city = :city "//alabama
				+ "WHERE "
				+ "id = :id ");  //112

		
		
		
		addressQuery.setParameter("city",e.getAddress().getCity())//new value
			.setParameter("id",e.getAddress().getId())//to this perticular row
			.executeUpdate();
		
		Query employeeQuery = session.createQuery(""
				+ "UPDATE "
				+ "Emp "

				+ "SET "						
				+ "name = :name, "
				+ "password = :password, "
				+ "email = :email, "
				+ "address = :address "

				+ "WHERE "
				+ "id = :id ");

		employeeQuery.setParameter("name",e.getName())
		.setParameter("password",e.getPassword())
		.setParameter("email",e.getEmail())
		.setParameter("address",e.getAddress())
		.setParameter("id",e.getId())
		.executeUpdate();
		
		
	session.getTransaction().commit();}
	catch(Exception ex){
			session.getTransaction().rollback();
		}
*/
		
		
		
		
		
	}
		 
	
}
