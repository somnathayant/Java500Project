package com.ayantsoft.crudWithSpring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ayantsoft.crudWithSpring.dao.EmpDao;
import com.ayantsoft.hibernate.pojo.Emp;

@Service
public class EmpService {

	@Autowired
	private EmpDao empDao;

	public void insertEmpService(Emp emp){
		empDao.insertEmpDao(emp);

	}

	public List<Emp> getAllEmpService(){

		return empDao.getAllEmpDao();
	}

	public Emp getEmpByIdService(Integer id){

		return empDao.getEmpByIdDao(id);
	}
	
	public void updateEmpService(Emp emp){
		empDao.updateEmpDao(emp);

	}
}
