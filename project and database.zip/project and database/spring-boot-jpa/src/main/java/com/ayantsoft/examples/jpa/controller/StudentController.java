package com.ayantsoft.examples.jpa.controller;

import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.ayantsoft.examples.jpa.exceptions.StudentNotFoundException;
import com.ayantsoft.examples.jpa.model.Roles;
import com.ayantsoft.examples.jpa.model.Student;
import com.ayantsoft.examples.jpa.model.User;
import com.ayantsoft.examples.jpa.repository.AddressRepository;
import com.ayantsoft.examples.jpa.repository.RolesRepository;
//import com.ayantsoft.examples.jpa.repository.DepartmentRepository;
import com.ayantsoft.examples.jpa.repository.StudentRepository;
import com.ayantsoft.examples.jpa.repository.UserRepository;

@RestController
@RequestMapping("students")
public class StudentController {

	private final StudentRepository repository;
	private final AddressRepository addRepo;
	private final UserRepository userRepo;
	private final RolesRepository rolesRepo;
	
	public StudentController(StudentRepository repository,AddressRepository addRepo,UserRepository userRepo,RolesRepository rolesRepo) {
		this.repository = repository;
		this.addRepo=addRepo;
		this.userRepo=userRepo;
		this.rolesRepo=rolesRepo;
	}


	@GetMapping("/")
	public String pingController() {
		return "server running";
	}

	@GetMapping("students")
	public Iterable<Student> getStudents() {
		return repository.findAll();
	}	

	@GetMapping("{id}")
	public Student getStudent(@PathVariable Long id) {
		return repository.findById(id).orElseThrow(StudentNotFoundException::new);
	}

	@PostMapping("saveStudent")
	public Student addStudent(@RequestBody Student student) {
		return repository.save(student);
	}

	@PutMapping("updateStudent/{id}")
	public Student updateStudent(@PathVariable Long id, @RequestBody Student student) {
		Student studentToUpdate = repository.findById(id).orElseThrow(StudentNotFoundException::new);

		/*studentToUpdate.setFirstName(student.getFirstName());
		studentToUpdate.setLastName(student.getLastName());
		studentToUpdate.setYear(student.getYear());
		 */
		return repository.save(studentToUpdate);
	}

	@DeleteMapping("/{id}")
	public void deleteStudent(@PathVariable Long id) {
		repository.findById(id).orElseThrow(StudentNotFoundException::new);
		repository.deleteById(id);
	}
	@RequestMapping(value="/file",headers=("content-type=multipart/*"),method=RequestMethod.POST)//http://localhost:8082/corsRestForAng4/saveFile
	//@PostMapping("/file",headers=("content-type=multipart/*"))
	public void uploadFile(@RequestParam("file") MultipartFile file) {
		System.out.println(file.getSize());
	}

	@GetMapping("/getStudentsLessThanOrEqualParam/{id}")
	public Iterable<Student> getStudentsLessThanOrEqualParam(@PathVariable Long id) {
		return repository.getStudentsLessThanOrEqualParam(id);
	}	

	//multi table operation 

	@PostMapping("/saveStudent/multi")
	public void saveStudent(@RequestBody Student student) {

		//deptRepo.save(student.getDept());	
		addRepo.save(student.getAddress());
		repository.save(student);

	}
	@PostMapping("/saveUser/multi")
	public void saveUser(@RequestBody User user) {
				userRepo.save(user);
		
	}
	@GetMapping("/getRoles")
	public ResponseEntity<?> getRoles() {
	
		Optional<User> usrObj1=userRepo.findById(new Long(2));
		User usr1=usrObj1.get();
		Set<Roles>roles=usr1.getRoles();
		
		return new ResponseEntity<Set<Roles>>(roles,HttpStatus.OK);
	}



}
