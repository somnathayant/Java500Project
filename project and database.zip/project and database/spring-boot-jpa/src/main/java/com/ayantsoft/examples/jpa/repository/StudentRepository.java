package com.ayantsoft.examples.jpa.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.ayantsoft.examples.jpa.model.Student;

/*public interface StudentRepository extends CrudRepository<Student, Long> {

}*/


public interface StudentRepository extends JpaRepository<Student, Long> {
		
	
	/*@Query("SELECT t.title FROM Todo t where t.id = :id") 
    String findTitleById(@Param("id") Long id);
   */
		@Query("SELECT st.year FROM Student st where st.id <= :id")
		public Iterable<Student>getStudentsLessThanOrEqualParam(@Param("id") Long id);
}