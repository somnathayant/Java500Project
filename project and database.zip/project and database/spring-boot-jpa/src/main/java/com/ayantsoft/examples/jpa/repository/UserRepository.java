package com.ayantsoft.examples.jpa.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.ayantsoft.examples.jpa.model.Student;
import com.ayantsoft.examples.jpa.model.User;

public interface UserRepository extends JpaRepository<User, Long> {
			
	@Query("SELECT st.year FROM Student st where st.id <= :id")
	public Iterable<Student>getStudentsLessThanOrEqualParam(@Param("id") Long id);

}
