package com.ms.ACCTSERVICE.controller;

import java.util.Date;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;


@RequestMapping("/ACCT-SERVICE")
@RestController
public class AcctController {

	@GetMapping("/")
	public String ping() {
		return "ok";
	}
	
	@GetMapping("/getAll")
	public ResponseEntity<Data>getAll(){
		
		Data ob=new Data();
		ob.setDot(new Date());
		ob.setId(2005);
		ob.setName("somnath");
		
		return new ResponseEntity<Data>(ob,HttpStatus.OK);
	}
	
	  @GetMapping("/getDummy")
	  @CircuitBreaker(name = "default", fallbackMethod = "getDummyFallBack")
	  public ResponseEntity<Data>getDummy(){
		Data ob=new Data();
		ob.setDot(new Date());
		ob.setId(2001);
		ob.setName("Jitu Da");
		if(ob.getId()==2001) {
			throw new RuntimeException();
		}
		
		return new ResponseEntity<Data>(ob,HttpStatus.OK);
	}
	  
	public ResponseEntity<Data>getDummyFallBack(Exception ex){
		Data ob=new Data();
		ob.setName("FallBack  applied");
		return new ResponseEntity<Data>(ob,HttpStatus.OK);
	}
	
	
	@PostMapping("/setAll")
	public ResponseEntity<Data>setAll(@RequestBody Data ob){
		System.out.println(ob.getName());
		System.out.println(ob.getId());
		System.out.println(ob.getDot());
		
		return new ResponseEntity<Data>(ob,HttpStatus.OK);
	}
}
