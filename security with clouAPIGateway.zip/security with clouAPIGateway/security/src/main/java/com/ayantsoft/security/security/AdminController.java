package com.ayantsoft.security.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RequestMapping("/SECURITY-SERVICE")
@RestController
public class AdminController {

	@Autowired
	AuthenticationManager authenticationManager;
	@Autowired
	private MyUserDetailsService myUserDetailsService;
	@Autowired
	JwtUtil  JwtUtil; 
	
	

	@PostMapping("/")
	public ResponseEntity<?> ping(@RequestBody AuthReq authenticationReq) {
		String st=authenticationReq.getUserId();
		System.out.println(st);
		return new ResponseEntity<String>(authenticationReq.getUserId(),HttpStatus.OK);
	}

	//@PreAuthorize("hasRole('M')")
	@GetMapping("/getAdmin")
	public String ping2() {

		return "admin";
	}
	@GetMapping("/ACCT-SERVICE/getAll")
	public String getAll() {
        System.out.println("========getALL");
		return "ok";
	}

	//@PreAuthorize("hasRole('U')")
	@GetMapping("/getUser")
	public String ping1() {

		return "User";
	}


	@GetMapping("/getAny")
	public String ping3() {

		return "user or admin";
	}

	@PostMapping("/authenticate")
	public ResponseEntity<?>Authenticate(@RequestBody AuthReq authenticationReq){
		Authentication authentication=null;
		AuthRes authRes= null;
		HttpStatus httpStatus=null;
		try {
			authentication=authenticationManager.authenticate(
					new UsernamePasswordAuthenticationToken(authenticationReq.getUserId(),authenticationReq.getPassword())
					);

			if(authentication !=null && authentication.isAuthenticated()) {
				UserDetails userDetails=myUserDetailsService.loadUserByUsername(authenticationReq.getUserId());
				String jwt=JwtUtil.generateToken(userDetails);
				 authRes=new AuthRes(jwt);
				 httpStatus=HttpStatus.OK;
			}else {
				httpStatus=HttpStatus.UNAUTHORIZED;
				authRes=new AuthRes();
				authRes.setJwt("Not authenticated user ");
			}
		}catch(Exception e) {
			httpStatus=HttpStatus.UNAUTHORIZED;
			authRes=new AuthRes();
			authRes.setJwt(e.getMessage());
		}
		return new ResponseEntity<AuthRes>(authRes,httpStatus);
		

	}


}
