package com.ms.GATEWAYSERVER;





import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ReactiveHttpOutputMessage;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import org.springframework.web.client.RestTemplate;
import org.springframework.web.server.ServerWebExchange;

@Component
@Order(0)
public class AuthenticationFilter implements GlobalFilter {

	@Autowired
	private RestTemplate restTemplate;

	private static final Logger logger = LoggerFactory.getLogger(AuthenticationFilter.class);

	@Override
	public Mono<Void> filter(ServerWebExchange exchange, org.springframework.cloud.gateway.filter.GatewayFilterChain chain) {
		logger.info("Global Filter executed for request: {}", exchange.getRequest().getPath());

		ServerHttpRequest request = (ServerHttpRequest) exchange.getRequest();
		List<String> apiEndpoints = Arrays.asList("SECURITY-SERVICE");
		Predicate<ServerHttpRequest> isApiSecured = r -> apiEndpoints.stream()
				.noneMatch(uri -> r.getURI().getPath().contains(uri));  

		if (isApiSecured.test(request)) {
			if (!request.getHeaders().containsKey("Authorization")) {
				ServerHttpResponse response = exchange.getResponse();
				response.setStatusCode(HttpStatus.UNAUTHORIZED);

				return response.setComplete();
			}
			logger.info("Global Filter executed for request: 1{}", exchange.getRequest().getPath());

			HttpHeaders header = new HttpHeaders();
			final String token = exchange.getRequest().getHeaders().getOrEmpty("Authorization").get(0);
			logger.info("token {}",token);
			header.add("Authorization",token);
			logger.info("Global Filter executed for request: 2{}", token);
           try {
			ResponseEntity<String> response = restTemplate.exchange(
					"http://localhost:8080/SECURITY-SERVICE/"+exchange.getRequest().getPath(),
					HttpMethod.GET,
					new HttpEntity<>(String.class, header),
					String.class);  
           }catch(Exception ex) {
        		logger.info("Global Filter executed for request: 4{}", token);
				ServerHttpResponse responseReturn = (ServerHttpResponse) exchange.getResponse();
				((ServerHttpResponse) responseReturn).setStatusCode(HttpStatus.FORBIDDEN);
				return ((ReactiveHttpOutputMessage) responseReturn).setComplete();
	       }
			
		}
		return chain.filter(exchange);
	}
}



