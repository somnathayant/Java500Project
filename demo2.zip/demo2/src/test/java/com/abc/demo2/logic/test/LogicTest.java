package com.abc.demo2.logic.test;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import com.abc.demo2.logic.Logic;
import com.abc.demo2.logic.Logic1;

import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Spy;
import org.mockito.InjectMocks;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class LogicTest {

    @Mock
    Logic1 logic1;

    @Spy
    @InjectMocks
    Logic logic;

    @Test
    public void testSum() {
        when(logic1.sumReturn1(10)).thenReturn(25);
     // Mock Logic's own method
        doReturn(20).when(logic).sumReturn(10);
        try (MockedStatic<Logic> mockedStatic = mockStatic(Logic.class)) {
            // Arrange: mock the static method
            mockedStatic.when(() -> Logic.sumSt(10))
                        .thenReturn(90);
        
        logic.sum(10);
        verify(logic1).sumReturn1(10); // Verify that the mock was used
        }
    }
}
