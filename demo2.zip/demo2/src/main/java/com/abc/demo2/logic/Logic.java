package com.abc.demo2.logic;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class Logic {

    //private final Logic1 logic1;

    @Autowired
    private  Logic1 logic1;
	/*
	 * public Logic(Logic1 logic1) { this.logic1 = logic1; }
	 */

    public void sum(Integer j) {
    	int h=sumReturn(j);
        int g = logic1.sumReturn1(j);
        int k=sumSt(j);
        System.out.println("==return " + g+h+k);
    }

    public Integer sumReturn(Integer j) {
        System.out.println("sumr " + j);
        return j;
    }

    public static Integer sumSt(Integer j) {
        System.out.println("st"+j);
        return j;
    }
}
