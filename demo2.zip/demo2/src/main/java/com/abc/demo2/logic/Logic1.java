package com.abc.demo2.logic;

import org.springframework.stereotype.Service;

@Service
public class Logic1 {

    public Integer sumReturn1(Integer j) {
        System.out.println("sumr" + j); // For demo purposes; in production use a logger
        return j;
    }
}
