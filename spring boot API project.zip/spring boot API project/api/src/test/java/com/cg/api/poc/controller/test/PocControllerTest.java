package com.cg.api.poc.controller.test;


import org.junit.Before;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
//import org.junit.Test;
import com.cg.api.controller.PocController;
import com.cg.api.dto.EmployeeDto;
import com.cg.api.exception.handling.ResourceNotSavedException;
import com.cg.api.pojo.Address;
import com.cg.api.pojo.Employee;
import com.cg.api.repository.AddressRepository;
import com.cg.api.repository.EmployeeRepository;
import com.cg.api.service.EmployeeService;
import com.cg.api.service.impl.EmployeeServiceImpl;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class PocControllerTest {

	
	
	@InjectMocks
    private PocController pocController;

	@InjectMocks
    private EmployeeServiceImpl employeeService;

    @Mock
    private EmployeeRepository employeeRepository;

    @Mock
    private AddressRepository addressRepository;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testSaveEmployee()throws Exception {
       
    	
    	//
    	EmployeeDto e=new EmployeeDto();
    	e.setAddressId(200);
    	e.setEmpId(500);
    	
    	
    	Employee em=new Employee();
    	em.setEmpId(500);
		Address ad=new Address();
		ad.setAddressId(200);
		em.setAddress(ad);
		when(employeeRepository.save(em)).thenReturn(em);
		
		assertEquals(em, pocController.saveEmployee(e));
		
		
		
		
       
        
    }
	
	
	
	
	
	
}
