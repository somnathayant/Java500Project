package com.ayantsoft.ang4.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.ayantsoft.ang4.model.LoginClass;
import com.ayantsoft.ang4.model.LoginMst;
import com.ayantsoft.ang4.model.Student;


//as the class is annotated using @RestController now all the controller methods can be accessd by ip address
@RestController
public class UserController{

	

@RequestMapping(value="/",method=RequestMethod.GET)
public ModelAndView index(){
	ModelAndView mv = new ModelAndView("index");
	return mv;
}




/*@RequestMapping(value="/angLoging",method=RequestMethod.POST)//http://localhost:8081/corsRestForAng4/angLoging
public ResponseEntity<?> getLogin1(@RequestBody LoginMst login){//here data received using @requestBody
	
	System.out.println(login.getFirstname());//here after receiving the model you can do whatever you would like
	HttpStatus httpStatus = null;
	
	List<LoginMst>l=new ArrayList<LoginMst>();
	
	LoginMst login1=new LoginMst();
	login1.setFirstname("Fenil Patel");
	login1.setUserId("Somnath 001");
	login1.setMiddleName("kumar");
	login1.setLastname("Biswas");
	login1.setDescription("A User");
	login1.setPassword("somnathPassword");
		httpStatus=HttpStatus.OK;
	//return new ResponseEntity<List<LoginMst>>(l,httpStatus);
	return new ResponseEntity<LoginMst>(login1,httpStatus);
	
}*/



@RequestMapping(value="/getStudentData",method=RequestMethod.POST)//http://localhost:8081/corsRestForAng4/getStudentData
public ResponseEntity<?> getStudentData(@RequestBody Student st){//here data received using @requestBody
	
	
	System.out.println("========");
	System.out.println(st.getStudentName());
	System.out.println("=========");
	HttpStatus httpStatus = null;
	List<Student>stList=new ArrayList<Student>();
	
	Student st1=new Student();
	st1.setStudentName("Somnath1");
	st1.setRoll(22);
	
	Student st2=new Student();
	st2.setStudentName("vishal");
	st2.setRoll(24);
	
	stList.add(st2);
	stList.add(st1);
	
	httpStatus=HttpStatus.OK;
	return new ResponseEntity<List<Student>>(stList,httpStatus);
}

@RequestMapping(value="/getEmpData",method=RequestMethod.POST)//http://localhost:8081/corsRestForAng4/getStudentData
public ResponseEntity<?> getStudentData(@RequestBody Emp empObj){//here data received using @requestBody
	
	
	System.out.println("========");
	System.out.println(empObj.getEmpName());
	System.out.println(empObj.getEmpRoll());
	System.out.println("=========");
	
	HttpStatus httpStatus = null;
	
	List<Emp>empList=new ArrayList<Emp>();
	
	Emp e1=new Emp();
		e1.setEmpName("somnath Biswas");
		e1.setEmpRoll(22);
	Emp e2=new Emp();
		e2.setEmpName("Animesh Choudhary");
		e2.setEmpRoll(20);
		
	empList.add(e1);
	empList.add(e2);
	
	httpStatus=HttpStatus.OK;
	return new ResponseEntity<List<Emp>>(empList,httpStatus);
}

//This two controller methods are designed for interacting with angular 4 and angular js
//if you use same property named object from client side it will be catched here in the server side 

/*@RequestMapping(value="/angularJs",method=RequestMethod.GET)
public ModelAndView getLoginFromAngularJs(){
	ModelAndView mv=new ModelAndView();
	mv.setViewName("ang1");
	return mv;
}*/
/*@RequestMapping(value="/getAngularJs",method=RequestMethod.POST)
public void getData(@RequestBody User user){
	System.out.println(user.getUsername());
}*/

/*@RequestMapping(value="/getAngularJs",method=RequestMethod.POST)
public ResponseEntity<?> getUserData(){
	
	HttpStatus httpStatus = null;
	List<Student>stList=new ArrayList<Student>();
	
	Student st1=new Student();
	st1.setStudentName("Somnath");
	st1.setRoll(22);
	
	Student st2=new Student();
	st2.setStudentName("vishal");
	st2.setRoll(24);
	
	stList.add(st2);
	stList.add(st1);
	
	httpStatus=HttpStatus.OK;
	return new ResponseEntity<List<Student>>(stList,httpStatus);
	
	
}*/

}
