package com.ayantsoft.ang4.controller;

import java.io.Serializable;

public class Emp implements Serializable{

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 9072453910250849883L;

	private String empName;
	
	private Integer empRoll;
	
	//getter and setter

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public Integer getEmpRoll() {
		return empRoll;
	}

	public void setEmpRoll(Integer empRoll) {
		this.empRoll = empRoll;
	}
	
	
	
	
	
	
	
}
