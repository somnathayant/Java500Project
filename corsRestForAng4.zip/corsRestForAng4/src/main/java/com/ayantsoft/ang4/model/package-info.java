/**
 * 
 */
/**
 * @author somnath
 *
 */
package com.ayantsoft.ang4.model;