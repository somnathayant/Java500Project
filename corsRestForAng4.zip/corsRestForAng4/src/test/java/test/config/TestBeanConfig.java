package test.config;

import org.springframework.context.annotation.ComponentScan;

@ComponentScan(basePackages = "com.ayantsoft")

public class TestBeanConfig {

}
